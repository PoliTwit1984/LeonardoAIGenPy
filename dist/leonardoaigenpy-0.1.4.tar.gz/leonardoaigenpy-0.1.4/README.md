# LeonardoAIGenPy

LeonardoAIGenPy is a Python package for interacting with Leonardo AI to generate and upscale images.

## Installation

```bash
pip install LeonardoAIGenPy

```
